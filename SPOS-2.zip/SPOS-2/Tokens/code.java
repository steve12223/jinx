import java.util.Scanner;
/*tokens*/

public class Hello
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		int choice = in.nextInt();
		switch(choice)
		{
			case 1:
				while(false)
				{
				}
				break;
		}
	}
}