#include <stdio.h>

int add(int first, int second)
{
   printf("Addition is %d\n",(first+second));
   return (1);
}
