#include <stdio.h>

int mul(int first, int second)
{
   printf("Multiplication is %d\n",(first*second));
   return (3);
}
