import java.util.*;

public class MDT
{
	
}